Machine Learning Project

Group Members
1. Aditya Dutt
2. Richa Dutt
3. DingKang Wang
4. Bin XU
5. Kun Shi

Steps to run the project - 
1. To train the model run- python LSTM.py
2. TO validate model run- python validate_model.py
3. To test model run- python test_model.py

All the training features are stored in training_features.py
All the validation features are stored in validation_features.py
All the test features are stored in test_features.py
All the test djent features are stored in test_djent_features.py



